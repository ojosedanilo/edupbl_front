import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { authApi } from "../services/authApi";
import { clearAccessToken } from "@/shared/services/api";

export function useBootstrapAuth() {
  return useQuery({
    queryKey: ["bootstrap"],
    queryFn: authApi.refreshToken, // só renova o token; erro 401 = sem sessão ativa
    retry: false,
    staleTime: Infinity,
  });
}

export function useCurrentUser() {
  const { isSuccess } = useBootstrapAuth();

  return useQuery({
    queryKey: ["currentUser"],
    queryFn: authApi.getCurrentUser,
    // só executa após o bootstrap terminar com sucesso
    enabled: isSuccess,
    retry: false,
    staleTime: Infinity,
  });
}

export function useLogin() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: authApi.login,
    onSuccess: () => {
      queryClient.invalidateQueries();
    },
  });
}

export function useLogout() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: authApi.logout,
    onSuccess: () => {
      clearAccessToken();
      queryClient.clear();
      window.location.href = "/login";
    },
  });
}
