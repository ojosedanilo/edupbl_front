import type { ReactNode } from "react";
import { useBootstrapAuth } from "@/features/auth/hooks/useAuth";

type AppBootstrapProps = {
  children: ReactNode;
};

export function AppBootstrap({ children }: AppBootstrapProps) {
  const { isLoading } = useBootstrapAuth();

  // Aguarda o bootstrap terminar (sucesso ou 401) antes de renderizar as rotas.
  // Isso evita que o ProtectedRoutes ou PublicOnlyRoute tomem decisões
  // de redirect antes de saber se há sessão ativa.
  if (isLoading) return null;

  return <>{children}</>;
}
