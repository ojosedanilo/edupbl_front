import { Navigate, Outlet } from "react-router-dom";
import { useCurrentUser } from "@/features/auth/hooks/useAuth";
import { GradientBackdrop } from "@/components/layout/GradientBackdrop";

/**
 * Wrapper para rotas privadas.
 * Redireciona para /login se o usuário não estiver autenticado.
 */
export default function ProtectedRoutes() {
  const { data: user /*, isLoading */ } = useCurrentUser();

  /*
  if (isLoading) {
    return (
      <div className="relative flex min-h-screen items-center justify-center">
        <GradientBackdrop />
        <p className="relative z-10 text-white text-lg font-medium">Carregando…</p>
      </div>
    );
  }
  */

  if (!user) return <Navigate to="/login" replace />;

  return <Outlet />;
}
